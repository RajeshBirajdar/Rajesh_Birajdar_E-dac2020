package edacoops.java;

public class Casting {

	public static void main(String[] args) {
	int i=258;
	byte b;
	b = (byte)i;
	System.out.println(b);
	}

}
