package edacoops.java;
	import java.io.*;
	import java.util.*;
	import java.text.*;
	import java.math.*;
	import java.util.regex.*;

	/*public class Solution {
	      public static void main(String args[]){
	        Scanner sc=new Scanner(System.in);
	        int n=sc.nextInt();
	        int m=sc.nextInt();
	        
	        
	        for(int i=1;i<=n;i++){
	            for(int j=1;j<=m;j++){
	                if(i==1 || i==n ||j==1 || j==m){
	                
	                System.out.print("*");
	                }
	                else{
	                    System.out.print(" ");
	                }
	                
	               
	                
	            }
	             System.out.println();
	        }
	  }

	
	
	
	
	public class Solution {
	    public static void main(String args[] ) throws Exception {
	       Scanner sc=new Scanner(System.in);
	        int i,j,l=sc.nextInt(),k=sc.nextInt();
	        for(i=0;i<l;i++)
	        {
	            for(j=0;j<k;j++)
	            {
	                if(i==0 ||i==(l-1) ||j==0||j==(k-1))
	                    System.out.print("*");
	                else
	                    System.out.print(" ");
	                    
	            }
	            System.out.println();
	        }
	        
	    }
	}
	
	count duplicate element in array*/
	
	import java.io.*;
	import java.util.*;

	public class HollowRectangle {

	    public static void main(String[] args) {
	       Scanner sc=new Scanner(System.in);
	        int n=sc.nextInt();
	        int b[]=new int[n];
	        
	        for(int i=0;i<n;i++){
	            b[i]=sc.nextInt();
	        }
	        int count=0,x=0,temp=0,y=0;
	        for(int i=0;i<n;i++){
	            for(int j=i+1;j<b.length;j++){
	                if(b[i]==b[j] && y!=b[i]){
	                    temp++;
	                }
	            }
	            y=b[i];
	            if(temp>=1){
	                count++;
	                temp=0;
	            }
	        }
	        System.out.print(count);    
	        
	        
	        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
	    }
	}

