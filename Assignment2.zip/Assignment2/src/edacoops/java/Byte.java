package edacoops.java;

public class Byte {
	public static void main(String args[])
	   {
	
	
	
	
	byte b= 50;
	byte c = (byte)(b * (byte)2);
	System.out.println(c);
	b = (byte)(b * (byte)2);

}
}
