package edacoops.java;

public class SimpleInterest {

}
