package edacoops.java;

class Student
{

	int rollNo;
	String name;
	int age;
	double marks;


	Student()
	{
		rollNo = 1;
		name = "Raj Birajdar";
		age = 24;
		marks =70.5;
					
	}

	void studentDetails()
	{
		System.out.println("Roll Number:"+rollNo);
		System.out.println("Student Name:"+name);
		System.out.println("Student Age:"+age);
		System.out.println("Student Marks:"+marks);
		
	}

	void studentPara(int rn, String n, int a, double m)
	{
		rollNo=rn;
		name=n;
		age=a;
		marks=m;
		
	}
	}


	class StudentBook
	{
	    public static void main(String args[]) {
	    	
	    	Student s1=new Student();
	    	
	    	s1.studentDetails();
	    
	    	Student s2=new Student();
	    	s2.studentPara(2, "Baburao Apte", 60, 55);
	    	s2.studentDetails();
	    	
	    }
	}