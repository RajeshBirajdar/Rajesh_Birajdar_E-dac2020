package edacoops.java;

public class Test {
	int a;
	int b;
	Test(int a, int b)
	{
		this.a=a;
		this.b=b;
	}
	void print()
	{
		System.out.println(a);
		System.out.println(b);
	}
	

	
	public static void main(String[] args) {
		 Test s= new Test(5, 10);
		 s.print();
		

	}

}
