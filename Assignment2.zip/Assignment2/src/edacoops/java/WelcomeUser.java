package edacoops.java;

import java.util.Scanner;

public class WelcomeUser {

	       public static void main(String args[])
		   {
			String s1;
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter user name:");
			s1=sc.nextLine();
			
			System.out.println("Welcome"+s1);
			sc.close();
		   }
}
