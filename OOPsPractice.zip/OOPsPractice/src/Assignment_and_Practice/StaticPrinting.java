package Assignment_and_Practice;

public class StaticPrinting {

	int a=10;    //2 instance variables a,b
	int b=20;
	static void m1()   //static method
	{
		StaticPrinting t = new StaticPrinting();
		System.out.println(t.a);
		System.out.println(t.b);		
	}                   //method is completed object gets destroyed
	static void m2()
	{
		StaticPrinting t = new StaticPrinting();
		System.out.println(t.a);
		System.out.println(t.b);
	}
	public static void main(String args[])
	{
		StaticPrinting.m1();
		StaticPrinting.m2();
	}
	
}
