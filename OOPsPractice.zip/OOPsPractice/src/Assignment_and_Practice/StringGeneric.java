package Assignment_and_Practice;

class MyGen 
	{
		String ob;

		MyGen(String s)
		{
			this.ob = s;
		}

		void printOb()
		{
			System.out.println(ob);
		}

		String getOb()
		{
			return ob;
		}
	}
	


public class StringGeneric
{
		public static void main(String args[])
		{
			MyGen mg1 = new MyGen("Welcome");
			mg1.printOb();
			String s = mg1.getOb();
			System.out.println(s);
		}
	}

