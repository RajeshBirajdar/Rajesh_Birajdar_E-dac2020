package Assignment_and_Practice;

import java.util.ArrayList;
import java.util.Iterator;
 
class Employee1
{
	String name;
	int age;
	double salary;
	
	public Employee1(String n,int a,double s)
	{
		name = n;
		age = a;
		salary = s;
	}
}
public class ArrayListDemo {

	
	public static void main(String args[])
	{
		ArrayList <String> strList = new ArrayList<String> ();
		
		strList.add("Ram");
		strList.add("Shyam");
		strList.add("Sita");
		strList.add("Gita");
		strList.add("Mohit");
	
		System.out.println("Display using for each");	
	for(String s : strList)
	{
		System.out.println(s);
	}
	System.out.println("Display using iterator");	
	Iterator<String> it = strList.iterator();
	
	while(it.hasNext())
	{
		String st = it.next();
		System.out.println(st);
	}
	
	
	}	
}
