package Assignment_and_Practice;

class Q
{
	int val;
	boolean valSet = false;

	synchronized void put(int i)
	{
		try {
			if(valSet == true) {
				wait();
			}
		}
		catch (InterruptedException e)
		{
			System.out.println(e);
		}
		
		val = i;
		System.out.println("Produced: "+val);
		valSet = true;
		notify();
	}

	synchronized void get()
	{
		try {
			if(valSet == false) {
				wait();
			}
		}
		catch (InterruptedException e)
		{
			System.out.println(e);
		}
		System.out.println("Consumed: "+val);
		valSet = false;
		notify();
	}
}

class Producer implements Runnable
{
	Thread t;
	Q q;
	boolean running = true;

	Producer(Q q)
	{
		t = new Thread(this);
		this.q = q;
	}

	public void run()
	{
		int i = 0; 
		while(running)
		{
			q.put(i++);
		}
	}

	void stop()
	{
		running = false;
	}
}

class Consumer implements Runnable
{
	Thread t;
	Q q;
	boolean running = true;

	Consumer(Q q)
	{
		t = new Thread(this);
		this.q = q;
	}

	public void run()
	{
		int i = 0; 
		while(running)
		{
			q.get();
		}
	}

	void stop()
	{
		running = false;
	}
}


class ProducerConsumer
{
	public static void main(String args[])
	{
		Q q = new Q();
		 
		Producer pd = new Producer(q);
		Consumer cs = new Consumer(q);
		

		pd.t.start();
		cs.t.start();

		try{
			Thread.sleep(3000);
			pd.stop();
			cs.stop();

			
			pd.t.join();
			cs.t.join();
		}
		catch (InterruptedException e)
		{
			System.out.println(e);
		}
	}
}