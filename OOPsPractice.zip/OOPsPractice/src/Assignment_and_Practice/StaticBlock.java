package Assignment_and_Practice;

class Test11
{

	{
		System.out.println("Instance block-1");
	}
	{
		System.out.println("Instance block-2");
	}
	static 
	{
		System.out.println("Static block-1");
	}
	static 
	{
		System.out.println("Static block-2");
	}
	Test11()
	{
		System.out.println("0-argument constructor");
	
	}
	
	Test11(int a)
	{
		System.out.println("1-argument constructor");
	
	}

}

public class StaticBlock
{
	public static void main(String args[])
	{
	new Test11();
	new Test11(10);
	}
}
