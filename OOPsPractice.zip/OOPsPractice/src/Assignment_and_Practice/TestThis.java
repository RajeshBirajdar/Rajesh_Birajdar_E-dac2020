package Assignment_and_Practice;

public class TestThis {

	int a=400;
	public void add() {
		System.out.println(10+20);
		System.out.println(this.a);
		TestThis h = new TestThis();
		System.out.println(h.a);
	}
	public static void main(String[] args) {
		TestThis t = new TestThis();
		t.add();
		System.out.println(t.a);

	}

}
