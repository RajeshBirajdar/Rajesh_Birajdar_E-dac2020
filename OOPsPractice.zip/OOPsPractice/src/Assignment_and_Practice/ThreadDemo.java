package Assignment_and_Practice;

	class MyThread extends Thread
	{
		public MyThread(String threadName)
		{
			super(threadName);
		}

		public void run()
		{
			try {
				for(int i = 1; i <= 10; i++)
				{
					Thread.sleep(300);
					System.out.println(Thread.currentThread().getName() + " : " +i);
				}
			}
			catch (InterruptedException e)
			{
				System.out.println(e);
			}
		}

		public void fun()
		{
		}	
	}

	class ThreadDemo
	{
		public static void main(String args[])  
		{
			System.out.println("Main thread started");
			MyThread thread1 = new MyThread("First Thread");
			MyThread thread2 = new MyThread("Second Thread");
			
			thread1.start();		// execute run() for thread1
			thread2.start();		// execute run() for thread2
			thread1.setPriority(Thread.MIN_PRIORITY+2);	//priority : 3
			thread2.setPriority(Thread.NORM_PRIORITY+2);	//priority : 7
			try{
				Thread.sleep(4000);			//1000 millisecond = 1 second
			   }
			catch (InterruptedException e)
			   {
				System.out.println(e);
			   }
			System.out.println("Main thread ended");
		}
	}

