package Assignment_and_Practice;


class MyException extends RuntimeException
{
 String excpMsg;
 public MyException()
 {
 //super(excpMsg);
 excpMsg = "This is MyException default message";
 

 }
 public MyException(String excpMsg)
 {
 super(excpMsg);
 this.excpMsg = excpMsg;
 }
 //Following is overriding getMessge(). We can uncomment and check it.
 /*public String getMessage()
 {
 return ("Overriden getMessge() : "+this.excpMsg);
 }*/
}
class UserDefinedExceptionDemo
{
	
public static void fun() throws MyException
{
throw new MyException("exception is thrown to test MyException");
}
public static void main(String args[])
{
try{
fun();
}
catch(MyException me)
{
System.out.println(me.getMessage());
me.printStackTrace();
}
System.out.println("Terminating the application successfully");
} }



/*class Test
{
	void fun()
	{
	}
}

class ExceptionDemo
{
        public static void main(String args[])
        {
                int a = 5;
                int b = 0;

                int arr[] = {1,2,3,4,5};

		try
		{
		        System.out.println(a/b);		//Will give exception
		        //System.out.println(arr[6]);		//Will give exception
		}
		catch(ArithmeticException ae)
		{	System.out.println("Arithmetic exception generated and caught here");
			System.out.println(ae);
		}
		
                System.out.println("Our program executed successfully without any exception");
		//Code

		Test t = null;
		t.fun();
        }
}*/

