package Assignment_and_Practice;

class Test10
{
	Test10()
	{
		System.out.println("0-argument constructor");
	}
	                                          //always instance block will executes first
	{
		System.out.println("Instance block");
	}
}

public class InstanceBlock {
	
	public static void main(String args[])
	{
		new Test10();
	}
	

}
