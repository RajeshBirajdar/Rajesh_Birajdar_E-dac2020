package Assignment_and_Practice;

public class ConsCalling {

	ConsCalling()
	{
		this(10);     //must be first statement in constructor and one constructor is able to call only one constructor
		System.out.println("0 argument constructor calling");
	}
	
	ConsCalling(int a)
	{
		this(10, 20);
		System.out.println("1 argument constructor calling");
	}
	
	ConsCalling(int a, int b)
	{
		System.out.println("2 argument constructor calling");
	}
	
	public static void main(String args[])
	{
		ConsCalling c = new ConsCalling();
	}
	
}
