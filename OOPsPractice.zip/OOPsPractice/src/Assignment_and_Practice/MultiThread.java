package Assignment_and_Practice;

class Even extends Thread
	{
	    public void run()
	    {
	        for(int i=0;i<=10;i=+2)
	        {
	            System.out.println(Thread.currentThread().getName()+i);
	        }
	    }
	}
	class Odd extends Thread
	{
	   public void run()
	    {
	        for(int i=1;i<=10;i+=2)
	        {
	            System.out.println(Thread.currentThread().getName()+i);
	        }
	    }
	}
	class MultiThread
	{
	    public static void main(String[] args) {
	        System.out.println("MAIN START HUA....");
	        System.out.println("MAIN END HUA....");
	        Even mo = new Even();
	        Odd od = new Odd();
	        mo.start();
	        od.start();
	    }
	}
