package Assignment_and_Practice;

//import java.util.*;
	class MyGene 
	{
		String ob;

		MyGene(String s)
		{
			this.ob = s;
		}

		void printOb()
		{
			System.out.println(ob);
		}

		String getOb()
		{
			return ob;
		}
	}

	class GenericDemo
	{
		public static void main(String args[])
		{
			MyGene mg1 = new MyGene("Welcome");
			mg1.printOb();
			String s = mg1.getOb();
			System.out.println(s);
		}
	}
