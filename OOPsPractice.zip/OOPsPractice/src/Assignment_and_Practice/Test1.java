package Assignment_and_Practice;


class Parent 
{ 
    int value = 1000; 
} 
  
class Child extends Parent 
{ 
    int value = 10; 
} 
  

class Test1 
{ 
    public static void main(String[] args) 
    { 
        Parent cobj = new Child(); 
        Parent par = cobj;
  Child c1 = new Child();
       
       // if (par instanceof Child) 
        { 
            System.out.println("Value accessed through parent reference with typecasting is " + ((Child)par).value); //10
	     
        } 
	/*else
	{
	System.out.println("Not a instance");
	}
	System.out.println("Value accessed through parent reference with typecasting is " + par.value); //1000
	*/

	if(c1 instanceof Parent)
	{
	System.out.println("True");
	}

    } 
} 

