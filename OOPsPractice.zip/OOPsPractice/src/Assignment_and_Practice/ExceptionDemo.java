package Assignment_and_Practice;

class MyException1 extends Exception
{
	String excpMsg;

	MyException1()
	{
	}

	MyException1(String excpMsg)   //excpMsg = "This is my exception message"
	{
		super(excpMsg);
		this.excpMsg = excpMsg;
	}

	public String getMessage()
	{
		
		return "MyException1: " +excpMsg;
	}

	public String toString()
	{
		return "MyException1 generated";
	}
}

class ExceptionDemo
{
	public static void main(String args[])
	{
		int age = 16;

		try
		{
			if(age < 18)
			{
				MyException1 myExpObj = new MyException1("Age can not be less than 18!");
				throw myExpObj;
			}
			else
			{
				System.out.println("Vote Id card created");
			}
		}
		catch (MyException1 excp)
		{
			System.out.println(excp.getMessage());	
			System.out.println(excp);
		}
	}
}
