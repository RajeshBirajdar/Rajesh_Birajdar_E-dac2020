package com.EDACOOPS.java;

class Exception01 {
	 public static void main(String args[]) {
	int a=30,b;
	try {
	b=a/0;
	System.out.println(b);
	  }
	catch(Exception e) {
	  System.out.println(e);
	  }
	}
	}
