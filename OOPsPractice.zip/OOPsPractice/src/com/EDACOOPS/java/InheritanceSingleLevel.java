package com.EDACOOPS.java;

public class InheritanceSingleLevel {

	class Bank
	{
		String name;
		String address;
		
		void details()
		{
			System.out.println("Bank name"+name+"Bank address"+address);
		}
	}
	
	class Customer extends Bank
	{
		int accId;
		String name;
		String accType;
		
	
	}
	
}
