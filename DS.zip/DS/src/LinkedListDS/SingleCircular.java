package LinkedListDS;

class Node2
{
	int data;
	Node2 next;
}
public class SingleCircular
{
	Node2 head;
	SingleCircular()
	{
		head=null;
	}
	void insert(int data)
    {
        Node2 newNode=new Node2();
        newNode.data=data;
        newNode.next=null;
        if(head==null)
        {
            head=newNode;
        }
        else
        {
            Node2 n=head;
            while(n.next!=null)
            {
              n=n.next;  
            }
            n.next=newNode;
        }
    }

	void insertBeg(int data)
	{
		Node2 newNode=new Node2();
		newNode.data=data;
		newNode.next=null;
		if(head==null)
		{
			head=newNode;
			newNode.next=head;
		}
		else {
			Node2 t=new Node2();
			t=head;
			while(t.next !=head)
			t=t.next;
			t.next=newNode;
			newNode.next=head;
			head=newNode;
			
		}
	}
	void insertEnd(int data)
	{
	     	Node2 newNode=new Node2();
	     	newNode.data=data;
	     	newNode.next=null;
	     	if(head==null)
	     	{
	     		head=newNode;
	     		newNode.next=head;
	     	}
	     	else
	     	{
	     		Node2 t=new Node2();
	     		t=head;
	     		while(t.next !=head)
	     		t=t.next;
	     		t.next=newNode;
	     		newNode.next=head;
	     	}
	}
	void deleteBeg()
	{
		if(head !=null)
		{
			if(head.next==head)
			{
				head=null;
			}
			else{
				Node2 t=head;
				Node2 fn=head;
				while(t.next != head)
				{
					t=t.next;
			    }
			head=head.next;
			t.next=head;
			fn = null;
			}
		}
	}
void deleteEnd()
{
	if(head !=null)
	{
		if(head.next ==head)
		{
			head=null;
		}
		else
		{
			Node2 t= new Node2();
			t =head;
			while(t.next.next !=head)
				t=t.next;
				Node2 ln=t.next;
				t.next=head;
				ln=null;
		}
	}
}

	void printList()
    {
        Node2 t=head;
        while(t.next==null)
        {
            System.out.println(t.data);
            t=t.next;
 
        }
        System.out.println(t.data);
        
    }


public static void main(String args[])
{
	SingleCircular sl=new SingleCircular();
	sl.insertBeg(10);
	sl.insertBeg(20);
	sl.insertBeg(30);
	sl.insertEnd(40);
	
	//sl.insertPos(2,4);
	
	System.out.println();
	
	sl.deleteEnd();
	sl.deleteBeg();
	
	sl.printList();	
  }
}
