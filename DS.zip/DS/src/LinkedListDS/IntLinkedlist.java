package LinkedListDS;

 class IntLinkedlist0 {
	 class Node
		{
			private int value;
			private Node link;
		}
	private Node head;
	
	/*public IntLinkedlist0(int item)
	{
		head = new Node();
		head.value =item;
		head.link = null;
	}*/
	
	public boolean insertBeg(int item)
	{
		Node n = new Node();
		n.value = item;
		n.link = head;
		head = n;
		return true;
	}
	 public void deleteEnd()
	 {
		 Node n = new Node();
		if(head==null)
		{
			System.out.println("List is Empty");
		}
			while(n.link.link!=null)
			{
		      n=n.link;
			}
			n.link=null;
			
	 }
	 
	 
	 
	 
	 
	public boolean deleteItem(int item)
	{
		if(head.value==item)
		{
			head=head.link;
		return true;
		}else
		{
			Node x = head;
			Node y = head.link;
			while(true)
			{
				if(y!=null||y.value==item)
				{
					break;
				}else
				{
					x=y;
					y=y.link;
				}
			}
			if(y!=null)
			{
				x.link=y.link;
				return true;
			}else
			{
				return false;
			}
		}
	}
	public void printList()
	{
		Node z = head;
		while(z!=null)
		{
			System.out.println(z.value);
			z = z.link;
		}
	}
}
public class IntLinkedlist
{
	public static void main(String[] args)
	{
		IntLinkedlist0 list = new IntLinkedlist0();
		list.insertBeg(4);
		list.insertBeg(6);
		list.insertBeg(8);
		//list.insertBeg(10);
		//list.insertBeg(12);
		//list.deleteEnd();
		list.printList();
		
		//list.deleteItem(10);
		//list.deleteItem(12);
		list.deleteItem(4);
		System.out.println("After deleting the items");
		list.printList();
		
	}
}
