package LinkedListDS;



class NodeL
{
    int data;
    NodeL next;
    NodeL tail;
}
class LinkList0
{
    NodeL head;
    
    NodeL tail=null;
    
    void insertbeg(int data)
    {
        NodeL nd=new NodeL();
        nd.data=data;
        nd.next=null;
        nd.next=head;
        head=nd;
    }
    void insertAt(int index,int data)
    {
       
        NodeL nd=new NodeL();
        nd.data=data;
        nd.next=null;
        if(index==0)
        {
            insertbeg(data);
        }
        NodeL n=head;
        for(int i=0;i<index-1;i++)
        {
            n=n.next;
        }
        nd.next=n.next;
        n.next=nd;
    }
    void insertAtend(int data)
    {
        NodeL nd=new NodeL();
        nd.data=data;
        if(head==null)
        {
            head=nd;
        }
        else
        {
        NodeL n=head;
        while(n.next!=null) {
           n=n.next;}
        n.next=nd;
        }   
    }
    void deleteAtbeg()
    {
        if(head==null)
        {
            System.out.println("List is empty");
        //return;
        }
        else
        {
            if(head!=tail)
            {
                head=head.next;
            }
            else
            {
                head=tail=null;
            }
        }
        
    }
    void deleteAt(int index)
    {
        if(index==0)
        {
            head=head.next;
        }
        else
        {
            NodeL n=head;
            NodeL n1=null;
            for(int i=0;i<index-1;i++)
            {
                n=n.next;
            }
            n1=n.next;
            n.next=n1.next;
            //System.out.println("n1"+n1.data);
            n1=null;
        }
    }
    void deleteAtLast()
    {
        if(head==null)
        {
            System.out.println("list is empty");
        }
        NodeL n=head;
        while(n.next.next!=null)
        {
            n=n.next;
        }
        n.next=null;
        
    }
    
  /*  public void sortList()
    {
    	int c=0;
    	NodeL n = head;
    	while(n.next!=null)
    	{
    		NodeL m = head;
    		while(m.next!=null)
    		{
    			if(m.data<m.next.data)
    			{
    				c=m.data;
    				m.data=m.next.data;
    				m.next.data=c;
    				
    			}
    			m=m.next;
    		}
    		n=n.next;
    	}
    }*/
    
    
    
    
    
    void show()
    {
        NodeL n=head;
        while(n.next!=null)
        {
            System.out.println(n.data);
            n=n.next;
        }
        System.out.println(n.data);
        
    }
}
class LinkedList
{
    public static void main(String args[])
    {
       LinkList0 list=new LinkList0();
       list.insertbeg(40);
       list.insertbeg(20);
       list.insertbeg(50);
       list.insertbeg(85);
       list.insertbeg(60);
       //list.insertAtend(60);
       
       //list.insertbeg(50);
       //list.insertAt(1, 90);
     // list.insertAt(2, 80);
      //list.sortList();
       //list.deleteAt(3);
       //list.deleteAtbeg();
       //list.insertbeg(5);
       list.show();
      /* 
       list.deleteAtLast();
       //list.insertAtend(90);
       System.out.println("After deleting ");
       list.show();*/
    }
}
