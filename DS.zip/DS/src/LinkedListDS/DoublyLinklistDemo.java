package LinkedListDS;


class Node
{
		int data;
		Node next;
		Node prev;	
		
	Node(int data)
	{
		this.data=data;
		this.next=this.prev=null;
	}
}

class DoublyLinklist
{
	private Node start;
	private int length;
	
	DoublyLinklist(int data)
	{
		this.start=null;
		this.length=0;
		
	}
	
	public void insertAtBeg(int data)
	{
		Node newnode = new Node(data);
		if(start==null)
		{
			start=newnode;
		}
		else
		{
			start.prev=newnode;
			newnode.next=start;
			start=newnode;
		}
		length++;
	}
	
	public void insertAtEnd(int data)
	{
		Node newnode = new Node(data);
		if(start==null)
		{
			start=newnode;
		}
		Node n = start;
		while(n.next!=null)
		{
			n=n.next;
		}
		if(n.next==null)
		{
			n.next=newnode;
			newnode.prev=n;
		}
		length++;
	}
	
	public void insertAtPos(int data, int pos)
	{
		if(pos==1)
		{
			insertAtBeg(data);
		}
		else if(pos>length)
		{
			insertAtEnd(data);
		}
		else
		{	
		int i=1;
		Node n=start;
		while(n.next!=null)
		{
			i++;
		if(i==pos) 
			break;
		n=n.next;
		}
		Node newnode =new Node(data);
		newnode.prev=n;
		newnode.next=n.next;
		n.next=newnode;
		n.next.prev=newnode;
		}
		length++;
	}
	
	public void deleteAtBeg()
	{
		Node n=start;
		try{
		if(start==null)
		{
			System.out.println("List is Empty");
		}
		else
		{
			start=n.next;
			start.prev=null;
		}
		}catch(NullPointerException ne) {}
			System.out.println(n.data + "Delete");
		
		length--;
		
	}
	public void deleteAtEnd()
	{
		if(start==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node n = start;
		while(n.next.next!=null)
		{
			n=n.next;
		}
		n.next.prev=null;
		n.next=null;
		length--;
		}
	}
	
	public void deletePos(int pos)
	{
		if(pos==0)
		{
			System.out.println("The position not exist");
			return;
		}
		if(pos==1)
		{
			deleteAtBeg();
		}
		else if(pos>length)
		{
			deleteAtEnd();
		}
		else
		{
			int i=1;
			Node p = start;
			while(p.next!=null)
			{
				i++;
				if(i==pos)
					break;
				p=p.next;
			}
			//p.next.next
		}
	}

public void displayForward()
	{
		Node n = start;
		while(n.next!=null)
		{
			System.out.println(n.data);
			n=n.next;
		}
		System.out.println(n.data);
	}
}

public class DoublyLinklistDemo {
	
	public static void main(String [] args) throws Exception  {

	DoublyLinklist dlist = new DoublyLinklist(2);
	//dlist.insertAtBeg(10);
	dlist.insertAtBeg(20);
	dlist.insertAtBeg(22);
	//dlist.insertAtEnd(30);
	//dlist.insertAtEnd(40);
	
	dlist.displayForward();
	/*System.out.println("After inserting at position");
	dlist.insertAtPos(23, 2);
	dlist.insertAtPos(24, 3);
	dlist.displayForward();
	*/
	dlist.deleteAtBeg();
	
	//dlist.deleteAtEnd();
	dlist.deleteAtBeg();
	//System.out.println("After deleting the data");
	//dlist.displayForward();
}
}
