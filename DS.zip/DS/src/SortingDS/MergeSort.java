package SortingDS;

public class MergeSort
{
		int array[];
		int[] tempMergeArr;
		int length;
		public static void main(String args[])
		{
			int inputarr[]= {48,36,13,52,19,94,21};
			MergeSort ms=new MergeSort();
			ms.sort(inputarr);
			for(int i:inputarr)
			{
				System.out.print(i+" ");
			}
		}
		public void sort(int inputarr[])
		{
			this.array=inputarr;
			this.length=inputarr.length;
			this.tempMergeArr=new int[length];
			divideArray(0,length-1);
		}
		public void divideArray(int lowerIndex,int higherIndex)
		{
			if(lowerIndex<higherIndex)
			{
			int mid=(lowerIndex+higherIndex)/2;
			divideArray(lowerIndex,mid);//left side sorting of an array
			divideArray(mid+1,higherIndex);//right side sorting of an array
			mergeArray(lowerIndex,mid,higherIndex);
			}
		}
		public void mergeArray(int lowerIndex, int mid, int higherIndex)
		{
			for(int i=lowerIndex;i<=higherIndex;i++)
			{
				tempMergeArr[i]=array[i];
			}
			int i=lowerIndex;
			int j=mid+1;
			int k=lowerIndex;
			while(i<=mid && j<=higherIndex)
			{
				if(tempMergeArr[i]<=tempMergeArr[j])
				{
					array[k]=tempMergeArr[i];
					i++;
				}
				else
				{
					array[k]=tempMergeArr[j];
					j++;
				}
				k++;
			}
			while(i<=mid)
			{
				array[k]=tempMergeArr[i];
				k++;
				i++;
			}
		}	
	}

