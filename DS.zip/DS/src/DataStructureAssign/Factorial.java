package DataStructureAssign;

import java.util.Scanner;

public class Factorial {

	public static void main(String args[])
	{
		int i, fact=1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number: ");
		int number = sc.nextInt();
		
		for(i=1;i<=number;i++)
		{
			fact = fact*i;
		}
		System.out.println("Factorial of given number:"+fact);
		sc.close();
	}
}
