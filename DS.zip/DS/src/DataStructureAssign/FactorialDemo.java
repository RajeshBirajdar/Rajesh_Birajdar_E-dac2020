package DataStructureAssign;

import java.util.*;
public class FactorialDemo {
     
       static int fact(int n)
	{
		int output;
		if(n==1)
		{
			return 1;
		}      
		output = fact(n-1)*n;      //Recursion Function calling itself
		return output;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number:");
		int num = sc.nextInt();
		
		int factorial=fact(num);
		System.out.println("The factorial of given number: "+factorial);
		sc.close();
	}
}
