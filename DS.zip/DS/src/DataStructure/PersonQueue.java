package DataStructure;

class Person1
{
	private String name;
	private String rollNo;
	
	public Person1(String name, String rollNo)
	{
		this.name = name;
		this.rollNo = rollNo;
		
	}
	
	public String toString()
	{
		return "Name: "+this.name+ "Roll No: "+this.rollNo;
		
	}
}

class PersonQueue0
{
	private int size;
	private int total;
	private int front;
	private int rear;
	private Person1 arr[];


	public PersonQueue0()
	{
		size=10;
		total=0;
		front=0;
		rear=0;
		arr= new Person1[size];
		
	}
	
	public PersonQueue0(int size)
	{
		this.size=size;
		total=0;
		front=0;
		rear=0;
		arr= new Person1[this.size];
	
	}
	
	public boolean enqueue(Person1 item)
	{
		if(!isFull())
		{
			arr[rear]=item;
			total++;
			rear = (rear+1) % size;
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public Person1 dequeue()
	{
		Person1 item = arr[front];
		total--;
		front = (front+1) % size;
		return item;
	}
	
	public boolean isFull()
	{
		if(size==total)
		{
			return true;
		}
		else {return false;}
	}
	
	public boolean isEmpty()
	{
		if(size != total)
		{
			return true;		
		}
		else {return false;}
	}
	
	public void showAll()
	{
		if(total != 0)
		{
			for(int i=0; i<total; i++)
			{
			System.out.println(" "+arr[front].toString());
			front = (front+1) % size;
			}
		}
	}
}
public class PersonQueue {

	public static void main(String[] args)
	{
		Person1 p1 = new Person1("Raj", "111");
		Person1 p2 = new Person1("Ravi", "222");
		
		PersonQueue0 q = new PersonQueue0();
		
		q.enqueue(p1);
		q.enqueue(p2);
		
		q.dequeue();
		//System.out.println(q.dequeue());
		//System.out.println(q.dequeue());
		
		q.showAll();
		
	}
}
