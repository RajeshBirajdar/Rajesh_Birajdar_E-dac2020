package DataStructure;

 class IntStack
{
    private int top;
    private int size;
    private int arr[];
    //private int n;
    public IntStack()
    {
        top=-1;
        size=10;
        arr = new int[size];
    }
    
    public boolean push(int item)
    {
        if(!isFull())
        {top++;
        arr[top]=item;
        return true;
         }
        else
        {return false;}
    }
    
    public int pop()
    {
        return arr[top--];
    }
    
    public boolean isFull()
    {
       return(top==arr.length-1);
        
    }
}

public class Solution 
{
    public static void main(String[] args)
    {
    IntStack intstack = new IntStack();
    /*Scanner sc = new Scanner(System.in);
    int arrCount = sc.nextInt();
    //int arr[] = new int[arrCount];
    intstack.push(arrCount);*/
    intstack.push(1);
    intstack.push(2);
    intstack.push(3);
    System.out.println(intstack.pop());
    System.out.println(intstack.pop());
    System.out.println(intstack.pop());
    }
}
