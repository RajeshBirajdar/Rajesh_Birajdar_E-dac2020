package DataStructure;

class Stack0 {

	private int top;
	private int size;
	private int arr[];
	
	public Stack0()
	{
		top = -1;
		size = 10;
		arr = new int[size];
	}
	
	/*public Stack0(int size)
	{
		top = -1;
		this.size = size;
		arr = new int[this.size];
	}*/
	
	public boolean push(int item) 
	{
		if(!isFull())
		{
			top++;
		    arr[top]=item;
			return true;
		}else
		{
			return false;
		}
	}

    public boolean isFull()
    {
    	return(top==arr.length-1);
    }
    
    public int pop()
    {
    	return arr[top--];
    }
    
    public boolean isEmpty()
    {
    	if(top==-1);
    	{return true;}
    }
    void display(){
    	for (int i : arr) {
			System.out.println(i);
		}
    }
}

public class Stack1
{
	public static void main(String[] args)
	{
		Stack0 stack = new Stack0();
		
		if(!stack.isFull())
		{
			stack.push(2);
			stack.push(3);
			stack.push(4);
			stack.push(5);
			stack.push(6);			
		}
		
		stack.display();
			
		
		
		System.out.println(stack.pop());
		System.out.println(stack.pop());
	}
}