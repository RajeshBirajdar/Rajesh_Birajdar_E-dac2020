package DataStructure;

 class Person
{
	private String name;
	private String rollNo;


  public Person(String name, String rollNo)
  {
	  this.name=name;
	  this.rollNo=rollNo;
  }

  public String toString()
{
	return("Name: " +name + " Roll No: " +rollNo);
}

}
 
 
 class PersonStack0
{
	private int top;
	private int size;
	private Person []arr;
	
	public PersonStack0()
	{
		top= -1; 
		size = 10;
		arr = new Person[10];
	}

	 public PersonStack0(int size)
	 {
		 top=-1;
		 this.size=size;
		 arr = new Person[this.size];
	 }

	public boolean push(Person item)
	{
		if(!isFull())
		{
			top++;
			arr[top]=item;
			return true;
		}else
		{return false;}
	}
	
	public Person pop()
	{
		return arr[top--];
	}
	public boolean isEmpty()
	{
		return(top==-1);
	}
	
	public boolean isFull()
	{
		return(top==arr.length-1);
	}
	
}


public class PersonStack {
	
	public static void main(String[] args)
	{
		Person p1 = new Person("Raj", "111");
		Person p2 = new Person("Ravi", "222");
		System.out.println("printing input:1 " +p1);
		System.out.println("printing input:2 " +p2);

		PersonStack0 pstack = new PersonStack0();
		
		if(!pstack.isFull())
		{
			pstack.push(p1);
			pstack.push(p2);
		}
		
		System.out.println(pstack.pop());
		System.out.println(pstack.pop());
		
	}
	
}