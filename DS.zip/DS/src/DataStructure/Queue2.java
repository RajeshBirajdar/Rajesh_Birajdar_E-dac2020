package DataStructure;

class Intq
{
	private int size;
	private int total;
	private int front;
	private int rear;
	private int arr[];
	
	public Intq()
	{
		size = 5;
		total = 0;
		front = 0;
		rear = 0;
		arr = new int[size];
	}
	public Intq(int size)
	{
		this.size = size;
		total = 0;
		front = 0;
		rear = 0;
		arr = new int[this.size];
	}
	
	public boolean enqueue(int item)
	{
		if(!isFull())
		{
			total++;
			arr[rear]=item;
			rear = (rear+1) % size;
			return true;
		}
		else {
			System.out.println("Queue is full: ");
			return false;}
	}
	
	public int dequeue()
	{
		int item = arr[front];
		total--;
		front = (front+1) % size;
		return item;
	}
	
	
	public boolean isFull()
	{
		if(size==total)
		{
			return true;
		}
		else
		{return false;}
	}
	
	public void showAll()
	{
		//int f = front;
		if(total != 0)
		{
			for(int i=0; i<total; i++)
			{
				System.out.println(" " +arr[front]);
				front = (front+1) % size;
			}
		}
	}
}
	
public class Queue2 {
	
	public static void main(String[] args) 
	{
		Intq q = new Intq();
		q.enqueue(2);
		q.enqueue(3);
		q.enqueue(4);
		q.enqueue(5);
		q.enqueue(6);
		//q.enqueue(7);
		
		q.dequeue();
		//System.out.println(q.dequeue());
		//System.out.println(q.dequeue());
		
		q.showAll();
	}

}
