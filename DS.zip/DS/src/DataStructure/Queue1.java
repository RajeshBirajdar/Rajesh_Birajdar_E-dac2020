package DataStructure;

public class Queue1 {

	private int front;
	private int rear;
	private int size;
	private int arr[];	
	
	public Queue1()
	{
		front=0;
		rear=0;
		size=10;
		arr= new int[size];
	}
	
	public Queue1(int size)
	{
		front=0;
		rear=0;
		this.size=size;
		arr = new int[this.size];
		
	}
	
	public boolean enqueue(int item)
	{
		if(rear<size)
		{
			arr[rear]=item;
			rear++;
			return true;
		}
		else {return false;}
	}
}
	
	/*public boolean dequeue()
	{
		if(arr.length>0)
		{
			 //int arr[front];
			front++;
		}
	}
}*/










