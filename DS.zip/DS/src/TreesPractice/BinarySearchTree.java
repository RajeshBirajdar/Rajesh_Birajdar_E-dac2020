package TreesPractice;

class BST1
{
	Node root;
	
	class Node
	{
		Node left, right;
		int data;
	}
	
	public BST1()
	{
		root=null;
	}
	
	public boolean insert(int item)
	{
		Node n = new Node();
		n.data=item;
		n.left=null;
		n.right=null;
		if(root == null)
		{
			root = n;
			return true;
		}
		Node p = root;
		Node c = root;
		while(c != null)
		{
			p = c;
			if(item < c.data)
			{
				c = c.left;
			}
			else
			{
				c = c.right;
			}
		}
		if(item < p.data)
		{
			p.left=n;
		}
		else
		{
			p.right=n;
		}		
		return true;
	}
	
	public Node findNode(int key)
	{
		Node c = root;
		while(c != null)
		{
			if(key == c.data)
			{
				break;
			}
			if(key < c.data)
			{
				c = c.left;
			}
			if(key > c.data)
			{
				c = c.right;
			}
		}
		return c;
	}
	
	public void showAll(Node n)
	{
		Node p = n;
		if(p != null)
			System.out.println(" " +p.data);
		try{showAll(p.left);
		showAll(p.right);}
		catch(NullPointerException e) {}
	}
}

public class BinarySearchTree {
	
	public static void main(String[] args) {	
		BST1 bst = new BST1();
	bst.insert(10);
	bst.insert(30);
	bst.insert(40);
	bst.insert(20);
	bst.insert(25);
	bst.insert(18);
	bst.insert(22);
	
	bst.findNode(10);
	
	bst.showAll(bst.findNode(10));
	
			
	}
}
